CREATE DATABASE StudentProfilesDB;

USE StudentProfilesDB;
sys_config

CREATE TABLE Profile(

studentID VARCHAR(20) PRIMARY KEY,

name VARCHAR(100),

programme VARCHAR(100),

email VARCHAR(100),

hobbies VARCHAR(255),

introduction VARCHAR(500)

);profileprofileprofileprofileprofileCREATE DATABASE StudentProfilesDB;
